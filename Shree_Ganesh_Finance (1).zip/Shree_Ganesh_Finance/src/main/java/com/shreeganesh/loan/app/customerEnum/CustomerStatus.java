package com.shreeganesh.loan.app.customerEnum;

public enum CustomerStatus {
	
	CibilOK,CibilNotOK

}
