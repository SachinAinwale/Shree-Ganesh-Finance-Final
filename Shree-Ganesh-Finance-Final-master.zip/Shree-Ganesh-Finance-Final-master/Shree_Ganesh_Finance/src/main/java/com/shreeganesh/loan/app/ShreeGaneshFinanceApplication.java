package com.shreeganesh.loan.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShreeGaneshFinanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShreeGaneshFinanceApplication.class, args);
		System.out.println("Jai GAnesh");
	}

}
